BOT_TOKEN = 'YOUR:own_private_secure-Bot_token'
PAYMENTS_PROVIDER_TOKEN = '012345678:TEST:1234'

TIME_MACHINE_IMAGE_URL = 'http://erkelzaar.tsudao.com/models/perrotta/TIME_MACHINE.jpg'
