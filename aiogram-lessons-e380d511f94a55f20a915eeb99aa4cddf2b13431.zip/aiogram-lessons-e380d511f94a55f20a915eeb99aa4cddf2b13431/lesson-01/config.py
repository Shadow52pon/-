TOKEN = 'YOUR:own_private_secure-Bot_token'
