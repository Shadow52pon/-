TOKEN = 'YOUR:own_private_secure-Bot_token'
MY_ID = 77777

DB_FILENAME = 'botuploads.db'
